package app;

public class InputException extends Exception {
	public InputException(String msg)
	{
		super(msg);
	}
}
