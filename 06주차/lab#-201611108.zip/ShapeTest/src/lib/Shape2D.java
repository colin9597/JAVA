package lib;

public interface Shape2D {
	public double findarea();
}
