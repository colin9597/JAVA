package lib;

public interface Shape3D {
	public double findvolume();	
}
