package lib;

public interface ValuePI {
	public static final double PI=3.14;
}
