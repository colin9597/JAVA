@FunctionalInterface
public interface Exchangeable {
	public int exchange(double money, int i);
}
