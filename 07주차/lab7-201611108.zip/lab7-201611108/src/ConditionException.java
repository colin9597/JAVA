
public class ConditionException extends Exception{
	public ConditionException(String msg) {
		super(msg);
	}
}